    $(document).ready(function () {
        // Instructions expand/collapse
        var content = $('#instructionBody');
        var trigger = $('#collapseTrigger');
        // content.hide();
        $('.collapse-text').text('(Click to collapse)');
        trigger.click(function () {
            content.toggle();
            var isVisible = content.is(':visible');
            if (isVisible) {
                $('.collapse-text').text('(Click to collapse)');
            } else {
                $('.collapse-text').text('(Click to expand)');
            }
        });
        // end expand/collapse
        display("typeList", "typeTable");
    });

    function display(inID, outID) {
        var str = document.getElementById(inID).textContent;
        if (str == "null") document.getElementById(outID).innerHTML = "Sorry, no types now.";
        else {
            var types = str.split("::");
            var num = types.length;

            var str1 = "<div class='checkbox'>[<a href='http://dbpedia.org/ontology/";
            var str2 = "' target='_blank'>Definition</a>] [<a href='http://mappings.dbpedia.org/server/ontology/classes/#";
            var str3 = "' target='_blank'>Class Hierarchy</a>] <label><input name='entityType' id='eType_";
            var str4 = "' type='checkbox' onclick='clearNone()' value='";
            var str5 = "'/>";
            var str6 = "</label> </div>";

            var html = '';
            if (num > 0) {
                for (var i = 1; i <= num; i++) {
                    var type = types[i - 1];
                    var item = str1 + type + str2 + type + str3 + i.toString() + str4 + type + str5 + type + str6;
                    html += item;
                }
            } else {
                html += "Sorry, no instance now.";
            }
            var html1 = document.getElementById(outID).innerHTML;
            document.getElementById(outID).innerHTML = html + html1;
        }
    }
    function clearType() {
        var keyword1 = "entityType";
        var keyword2 = "eType_";
        var types = document.getElementsByName(keyword1);

        for (var i = 1; i < types.length; i++) {
            var type = document.getElementById(keyword2 + i.toString());
            type.checked = false;
        }
    }

    function clearNone() {
        var keyword = "eType_0";
        var noType = document.getElementById(keyword);
        noType.checked = false;
    }
    function check() {
        var keyword1 = "entityType";
        var keyword2 = "eType_";
        var types = document.getElementsByName(keyword1);
        var count = 0;
        for (var i = 0; i < types.length; i++) {
            var type = document.getElementById(keyword2 + i.toString());
            if (type.checked) count++;
        }

        if (count > 0) return true;
        else {
            alert("You must choose at least one item! ");
            return false;
        }
    }

<!-- CLose internal javascript -->